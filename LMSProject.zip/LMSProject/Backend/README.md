# backend
LMS Backend

Steps for setup:

Step 1: npm install

Step 2: Open "config/default.json" file and provide the necessary values

Step 3: npm start

# frontend
LMS Frontend

Steps for setup:

Step 1: npm install

Step 2: npm start
